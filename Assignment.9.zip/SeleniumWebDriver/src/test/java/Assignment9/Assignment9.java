package Assignment9;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Assignment9 {

	public static void main(String[] args) throws InterruptedException
	{
	   WebDriver driver= new ChromeDriver();
		//WebDriver driver= new EdgeDriver();
	   
		driver.get("https://ineuron-courses.vercel.app/login");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//a[text()='New user? Signup']")).click();
		Thread.sleep(2000);
		
       boolean statusBefore=driver.findElement(By.xpath("//button[normalize-space()='Sign up']")).isEnabled();
		
		System.out.println("Status before entering values "+statusBefore);
		
		driver.findElement(By.xpath("//Input[@placeholder='Name']")).sendKeys("Puspanjali khora");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//Input[@placeholder='Email']")).sendKeys("Puspanjali1998@gmail.com");
      
	
		driver.findElement(By.xpath("//Input[@placeholder='Password']")).sendKeys("Anjali970");
	

		driver.findElement(By.xpath("//label[text()='Testing']")).click();
		
		//to perform Scroll on application using Selenium
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,850)");
		
	
		driver.findElement(By.xpath("//input[@value='Female']")).click();
		//Select DDlist= new Select(driver.findElement(By.xpath("//select[@name='state']")));
				Select DDlist= new Select(driver.findElement(By.id("state")));
		DDlist.selectByVisibleText("Odisha");	
		
       boolean statusAfter=driver.findElement(By.xpath("//button[normalize-space()='Sign up']")).isEnabled();
		
		System.out.println("Status before entering values "+statusAfter);
		
		JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(0,250)");
		
		//driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		JavascriptExecutor je=(JavascriptExecutor)driver;
		
		WebElement ele=driver.findElement(By.xpath("//button[normalize-space()='Sign up']"));
		
		je.executeScript("arguments[0].click()",ele);
		
        Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys("Puspanjali1998@gmail.com");
	
		
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("Anjali970");
		
		driver.findElement(By.xpath("//button[text()='Sign in']")).click();
		driver.close();
		

       
	}

}
